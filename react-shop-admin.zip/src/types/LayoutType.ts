import React from 'react';
export type LayoutType = {
  children: React.ReactElement[];
};

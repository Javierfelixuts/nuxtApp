import LoginPage from '@components/LoginPage';

import React from 'react';

const login = () => {
  return <LoginPage />;
};

export default login;
